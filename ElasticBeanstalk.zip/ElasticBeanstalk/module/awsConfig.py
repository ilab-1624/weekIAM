# aws base config
regionName = 'us-west-2'
aws_access_key_id = ''
aws_secret_access_key = ''

# dynamoDB
table = 'config'

# cognito
userPoolId = ''
clientId = ''

# rekognition
collectionId = 'ai-bigdata-system-collection'

# S3
bucketName = 'ai-bigdata-system-webapp-face-image'
faceImageFolderName = 'registration-faces'
externalFileName = 'rekognition.json'