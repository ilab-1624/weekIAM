from . import chatBotConfig
from linebot import WebhookHandler, LineBotApi
from linebot.exceptions import InvalidSignatureError, LineBotApiError
from linebot.models import FollowEvent, TextSendMessage, MessageEvent, TextMessage, MemberJoinedEvent


class LineApi:
    def __init__(self):
        self.__channelSecret = chatBotConfig.channelSecret
        self.__channelAccessToken = chatBotConfig.channelAccessToken
        self.__handler = WebhookHandler(self.__channelSecret)
        self.__lineBotApi = LineBotApi(self.__channelAccessToken)
    
    def verifySignature(self, event):
        try:
            self.__handler.handle(event['body'], event['signature'])
            
            return {'statusCode': 200, 'body': 'Success'}
            
        except InvalidSignatureError:
            return {'statusCode': 400, 'body': 'InvalidSignature'}
        
        except LineBotApiError as e:
            print(e.error.message)
            return {'statusCode': 500, 'body': e.error.message}
    
    def getUserProfile(self, daoData):
        try:
            response = self.__lineBotApi.get_profile(daoData['id']['custom:lineId'])
            daoData['userData'] = {
                'name': response.display_name
            }
            
            return {'statusCode': 200, 'body': daoData}
        
        except LineBotApiError as e:
            print(e.error.message)
            return {'statusCode': 500, 'body': e.error.message}