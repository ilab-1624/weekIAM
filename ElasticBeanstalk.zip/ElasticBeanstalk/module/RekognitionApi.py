from . import awsConfig
from botocore.exceptions import ClientError, ParamValidationError
import boto3
import base64


class RekognitionApi:
    def __init__(self):
        self.__regionName = awsConfig.regionName
        self.__aws_access_key_id = awsConfig.aws_access_key_id
        self.__aws_secret_access_key = awsConfig.aws_secret_access_key
        self.__client = boto3.client(
            'rekognition',
            region_name=self.__regionName,
            aws_access_key_id=self.__aws_access_key_id,
            aws_secret_access_key=self.__aws_secret_access_key
        )
    def addToFaceCollection(self, daoData):
        try:
            response = self.__client.index_faces(
                CollectionId=awsConfig.collectionId,
                Image={'Bytes': base64.b64decode(daoData['userData']['picture'])},
                MaxFaces=1,
                ExternalImageId=daoData['userData']['username'],
                QualityFilter="AUTO",
                DetectionAttributes=['ALL']
            )
            
            return {'statusCode': 200, 'body': response}
        
        except ClientError as e:
            print(e.response)
            return {'statusCode': 500, 'body': e.response['Error']['Message']}
        
        except ParamValidationError as error:
            print(error.kwargs['report'])
            return {'statusCode': 500, 'body': error.kwargs['report']}