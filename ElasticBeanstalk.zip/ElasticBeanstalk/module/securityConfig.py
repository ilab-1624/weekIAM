EdwareAgentsecurityStatus = "disable"
TommyAgentsecurityStatus = "enable"
MaxAgentsecurityStatus = "enable"

customerRole = 'customerRole'
staffRole = 'staffRole'
managerRole = 'managerRole'